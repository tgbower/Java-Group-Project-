package snakegame;

public class SnakePart {
    private Location location;
    
    public SnakePart(Location location) {
        this.location = location;
    }

    public Location getLocation() {
        return location;
    }    
}
