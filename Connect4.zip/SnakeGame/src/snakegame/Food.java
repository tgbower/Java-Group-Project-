package snakegame;

import java.awt.Color;

public class Food {
    private Location location;
    private Color color;
    private Integer points;
    
    public Food(Location location, Color color, Integer points) {
        this.location = location;
        this.color = color;
        this.points = points;
    }

    public Location getLocation() {
        return location;
    }

    public Color getColor() {
        return color;
    }

    public Integer getPoints() {
        return points;
    }
}
