package snakegame;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

public class Snake {
    private Direction direction;
    private List<SnakePart> snakeParts;
    private Color color;
 
    public Snake(Location start, Direction direction, 
            Integer numberOfBodyParts, Color color) {
        snakeParts = new ArrayList();
        this.direction = direction;
        this.color = color;
        for(int i = 0; i < numberOfBodyParts; i++) {
            Location location = new Location(
                    start.getX() - (i * GameSettings.SCALE), 
                    start.getY()
            );
            snakeParts.add(new SnakePart(location));
        }
    }
    
    public SnakePart[] getBodyParts() {
        SnakePart[] snakeParts = new SnakePart[this.snakeParts.size()];
        this.snakeParts.toArray(snakeParts);
        return snakeParts;
    }
    
    public Color getColor() {
        return this.color;
    }
    
    public void move() {
        SnakePart snakePart = snakeParts.remove(snakeParts.size() - 1);
        Location headLocation = snakeParts.get(0).getLocation();
        
        switch(this.direction) {
            case RIGHT:
                snakePart.getLocation().setX(headLocation.getX() + GameSettings.SCALE);
                snakePart.getLocation().setY(headLocation.getY());
                break;
            case LEFT:
                snakePart.getLocation().setX(headLocation.getX() - GameSettings.SCALE);
                snakePart.getLocation().setY(headLocation.getY());
                break;
            case UP:
                snakePart.getLocation().setX(headLocation.getX());
                snakePart.getLocation().setY(headLocation.getY() - GameSettings.SCALE);
                break;
            case DOWN:
                snakePart.getLocation().setX(headLocation.getX());
                snakePart.getLocation().setY(headLocation.getY() + GameSettings.SCALE);
                break;
        }
        
        snakeParts.add(0, snakePart);
    }

    public void setDirection(Direction direction) {
        this.direction = direction;
    }
    
    public SnakePart getHeadOftheSnake() {
        return snakeParts.get(0);
    }
    
    public void eat() {
        Location location = snakeParts.get(snakeParts.size() - 1).getLocation();        
        SnakePart snakePart = new SnakePart(location.clone());
        snakeParts.add(snakePart);
    }
}
