package snakegame;

import java.util.Objects;
import java.util.Random;
import static snakegame.GameSettings.GAME_HEIGHT;
import static snakegame.GameSettings.GAME_WIDTH;
import static snakegame.GameSettings.SCALE;

public class Location {
    private Integer x;
    private Integer y;
    
    public Location(Integer x, Integer y) {
        this.x = x;
        this.y = y;
    }

    public Integer getX() {
        return x;
    }

    public void setX(Integer x) {
        this.x = x;
    }

    public Integer getY() {
        return y;
    }

    public void setY(Integer y) {
        this.y = y;
    }
    
    public boolean equals(Location location) {
        return this.x.equals(location.getX()) &&
               this.y.equals(location.getY());
    }
    
    public Location clone() {
        return new Location(x, y);
    }
    
    public static Location getRandomLocation() {
        Random random = new Random();
        Integer x = random.nextInt(GAME_WIDTH/SCALE) * SCALE ;
        Integer y = random.nextInt(GAME_HEIGHT/SCALE) * SCALE ;
        return new Location(x, y);
    }
}
