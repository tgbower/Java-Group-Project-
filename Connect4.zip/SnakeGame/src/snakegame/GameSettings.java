package snakegame;

import java.awt.Color;

public class GameSettings {
    public final static Integer SCALE = 10;
    public final static Integer SPEED = 50;
    public final static Integer FOOD_COUNT = 10;
    public final static Integer GAME_WIDTH = 500;
    public final static Integer GAME_HEIGHT = 500;    
    public final static Color FOOD_COLOR = Color.RED;
    public final static Integer FOOD_POINTS = 1;
}
